SDL Chat - A multiplatform room based chat implemented using C and SDL

2003 (c) Copyright by Carlucio Santos Cordeiro.
